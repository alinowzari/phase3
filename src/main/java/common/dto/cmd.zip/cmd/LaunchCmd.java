// src/main/java/common/dto/cmd/LaunchCmd.java
package common.dto.cmd;

public record LaunchCmd(long seq) implements ClientCommand {}
